=== TRS Sales Count Down ===
Contributors: alishanvr
Tags: sales countdown, countdown, counter, woocommerce countdown, e-commerce, store, sales, sell, woosales, shopsales countdown, downloads, woo commerce, trs sales count down, sales countdown,
Requires at least: 5.0
Tested up to: 6.1
Requires PHP: 7.0
Stable tag: 5.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

== Description ==
WP Sales Countdown counts the sale end time. WP Sales Countdown for WooCommerce plugin is the best thing to increase sales.

== How WP Sales Countdown Works to Increase Your Sales == 
These days, customers look through site pages rather checking or reading the page’s content. This customer conduct makes e-commerce even more testing. In this way, your online store must have potential highlights to change over your site guests into customers. WP Sale countdown is one potential promoting methodology to help your online income. The WP Sales count down makes sales urgency and your customers will be compelled to settle on a speedy purchasing choice.

== Why You Need a WP Sales Count down? == 
WP Sales Count Down is necessary to increase your sales. It reminds the buyer that he must buy the items before the sale ends. Putting WP Sales Count Down beside each sale product reminds your customers that they just have a constrained measure of time to get it on a thing they have had their eye on. 


== Who Has Need for WP Sales Count Down? == 
The businesses in particular need a WP Sales Count Down. When they execute sales, they have to urge the customers to buy their products. The customers has to know that they need to buy their desired products in time. There are a few different ways to utilize urgency as a sales strategy; among them, one strategy is to show a countdown timer. WP Sales Countdown is an unmistakable viewable signal, which tells customers that, in the event that they need a product, they should make a move inside a predefined period. This could be a countdown until the finish of a sales period. 


The intensity of the WP Sales countdown is that the ticking down of the clock includes additional urgency in the customer's brain. They can really observe that time is running out and this becomes a factor in their buy choice. The key with WP Sales Countdown with the utilization of urgency overall, is that they offer valuable data to customers – which a sale will end soon or maybe that they have an hour or two remaining to arrange in the event that they need to get things the following day. 


== Where We Can Implement WP Sales Countdown? == 
WP Sales countdown can use where the sales are already executed or on any WooCommerce based store. Sometimes, the buyer thinks of buying a product but delays the process thinking that he would buy it tomorrow. However, with WP sales countdown, it would urge the customer to buy the product now because the time is running short and the sale will end soon. The conspicuous spot to utilize them is the place customers are thinking about a buy, thus they are all the more generally utilized on home and classification pages on ecommerce destinations, just as product pages. For instance, Amazon adds a countdown to delivery slice off times to make its product page progressively influential. The capacity to deliver things rapidly can be a compelling sales driver, and joining this with a delivery countdown is something that Amazon has accomplished for a considerable length of time. 


== Changelog ==
<strong>v 1.0.1</strong>
<ul>
    <li>Updated the readme file</li>
    <li>Tested with latest WordPress version 5.7</li>
    <li>Updated the plugin version</li>
</ul>  

<strong>v 1.0.0</strong>
<ul>
    <li>Initial Release</li> 
</ul> 
