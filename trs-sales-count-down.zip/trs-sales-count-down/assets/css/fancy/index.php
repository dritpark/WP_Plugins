<?php
/**
 * This file is used to prevent directory traversal attack.
 *
 * @file index.php
 * @package WooSalesCountDown
 */

// Silence is golden.

