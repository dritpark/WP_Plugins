"use strict";
jQuery(document).ready(function () {
    jQuery('.wcpr-swipebox').swipebox({
        hideBarsDelay: 100000
    });
});