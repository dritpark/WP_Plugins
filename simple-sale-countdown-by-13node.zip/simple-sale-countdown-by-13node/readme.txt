=== Simple Sale Countdown for Woocommerce by 13Node ===
Contributors: ulloa
Tags: countdown, timer, countdown timer
Requires at least: 3.8
Tested up to: 5.9
Stable tag: 1.3
Requires PHP: 5.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: Woocommerce, Sale Countdown 

Simple Woocommerce Sale Countdown

== Description ==
A very simple plugin to add <strong>countdown</strong> timer to your woocommerce products and woocommerce pages, using the built-in function from woocommerce.

We do web development and if you need a developer or if you think you have found a bug in Read more plugin, if you have any question, please feel free to contact us by this email info@13node.com.

== Credits ==

JS jQuery The Final Countdown by Hilios (https://github.com/hilios)

== Installation ==

1. Upload the 'trecenode-countdown' plugin folder to the '/wp-content/plugins/' directory.
2. Activate the "trecenode-countdown" list plugin through the 'Plugins' menu in WordPress.
3. Ready, add some sales with date and watch.

== Screenshots ==
1- Product
2- Product Page

== Changelog ==
= 1.3 =
* Hide Countdown and show regular price when sale date ends.
= 1.2 =
* Added native jquery support, fixed language translation
= 1.1 =
* Added Screenshots, images, and multi language support.
= 1.0 =
* Plugin publish