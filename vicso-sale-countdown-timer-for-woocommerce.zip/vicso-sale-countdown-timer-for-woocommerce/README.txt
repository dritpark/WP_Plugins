=== VICSO Sale Countdown Timer for WooCommerce ===
Contributors: vicso
Tags: countdown, countdown timer, sales countdown timer, sales timer, timer
Requires at least: 4.9.8
Tested up to: 5.6.1
Stable tag: 4.3
Requires PHP:  7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple but very useful tool for increasing online sales. A countdown timer for WooCommerce product pages with promotional price.

== Description ==

With this plugin, you can create a nice and functional sales countdown timer just in a few minutes. It's enough to install the plugin, set product sale price, and sale price dates (this is a standard feature of WooCoommerce sale price). And voila the countdown timer for the products with a special offer is ready. Pay attention, countdown timers are a popular tool to increase online sales.

Features of VICSO Sale Countdown Timer for WooCommerce
* Fully Responsive WooCommerce Countdown timer.
* Ability to implement the timer to unlimited product pages with the sale price.
* Ability to change the duration of the promotional price for different products.


== Installation ==

1. Upload `vicso-sale-countdown-timer-for-woocommerce.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Changelog ==

= 1.0 =
* Release this plugin to the masses!
