<?php

/**
 * @link       https://vicsothemes.com/
 * @since      1.0.0
 *
 * @package    Vicso_Sale_Countdown_Timer_For_Woocommerce
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
